
create create_logs_table  and table sturcture defind in figretion file
then using "php artisan migrate" command. for table create

dummy data store in log tables


"php artisan statistics:calculate" command run count calculate and stor in cache


visitor show count in /visitor  route in application


time taken to complete test is 8hrs. due laravel instalation issue and db connection issue in new envoirment
