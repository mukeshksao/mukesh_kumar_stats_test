
<style>
.styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 0.9em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
}

</style>

<table border="1" class="styled-table">

	<tr>    
	        <th>Date</th>
	        <th>Country</th>
		<th>Total Visit</th>
	
	</tr>
<?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($row->visitdate); ?></td>
<td><?php echo e($row->country); ?></td>
<td align="center"><?php echo e($row->total_visit); ?></td>

</tr>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH /data/html/laraveldemo/resources/views/visitor.blade.php ENDPATH**/ ?>