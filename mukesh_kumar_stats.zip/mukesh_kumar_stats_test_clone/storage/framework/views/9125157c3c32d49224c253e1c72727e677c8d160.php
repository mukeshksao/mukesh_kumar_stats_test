<table border="1">

	<tr>    
	        <th>Date</th>
	        <th>Country</th>
		<th>Total Visit</th>
	
	</tr>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($row->vdate); ?></td>
<td><?php echo e($row->country); ?></td>
<td><?php echo e($row->total_visit); ?></td>

</tr>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH /data/html/laraveldemo/resources/views/show.blade.php ENDPATH**/ ?>